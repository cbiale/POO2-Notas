package edu.unam.modelo;

public class Alumno {
    private int legajo;
    private Persona persona;

    public Alumno() {
    }

    public Alumno(int legajo, Persona persona) {
        this.legajo = legajo;
        this.persona = persona;
    }

    public int getLegajo() {
        return legajo;
    }

    public void setLegajo(int legajo) {
        this.legajo = legajo;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public String toString() {
        return this.legajo + " " + this.persona.getNombres() + " " + this.persona.getApellidos();
    }

}
