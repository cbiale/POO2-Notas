package edu.unam.ejemplo;

import edu.unam.ejemplo.modelo.Persona;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        var persona1 = new Persona();
        var persona2 = new Persona(1, "JUAN", "PEREZ");
        System.out.println(persona1);
        System.out.println(persona2);
    }
}
