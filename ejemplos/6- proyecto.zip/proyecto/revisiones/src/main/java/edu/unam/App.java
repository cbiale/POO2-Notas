package edu.unam;

import edu.unam.modelo.Curso;
import edu.unam.modelo.Revision;
import edu.unam.modelo.Persona;
import edu.unam.modelo.Alumno;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        var curso = new Curso("POO2");
        var revision1 = new Revision(1, "No me gusta", "Es largo y tedioso", curso);
        var revision2 = new Revision(5, "+ o -", "Es largo y cansador", curso);
        
        System.out.println(curso);
        System.out.println(revision1);
        System.out.println(revision2);
        System.out.println(curso.getRevisiones());

        var persona = new Persona("JUAN", "PEREZ");
        var alumno = new Alumno(1, persona);
        System.out.println(persona);
        System.out.println(alumno);
        
    }
}
